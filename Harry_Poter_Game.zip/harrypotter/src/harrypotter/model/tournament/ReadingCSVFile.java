package harrypotter.model.tournament;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadingCSVFile {
	public static void readFile(String path) throws IOException {
		
	}

	public static void main(String[] args) throws IOException {
		readFile("Database-Spells.csv");
	}

}
