package harrypotter.model.tournament;

import harrypotter.model.character.Champion;
import harrypotter.model.magic.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Tournament {
	ArrayList<Champion> champions;
	ArrayList<Spell> spells;
	FirstTask firstTask;
	SecondTask secondTask;
	ThirdTask thirdTask;

	public Tournament()throws IOException {
		loadSpells("Database-Spells.csv");

	}

	private void loadSpells(String filePath) throws IOException {
		String currentLine = "";
		FileReader fileReader = new FileReader(filePath);
		BufferedReader br = new BufferedReader(fileReader);
		while ((currentLine = br.readLine()) != null) {
			String x = currentLine;
			String[] y = x.split(",");
			int n1 = Integer.parseInt(y[2]);
			int n2 = Integer.parseInt(y[4]);
			int n3 = Integer.parseInt(y[3]);
			switch (y[0]) {
			case "DMG":
				spells.add(new DamagingSpell(y[1], n1, n2, n3));
				break;
			case "HEL":
				spells.add(new HealingSpell(y[1], n1, n2, n3));
				break;
			case "REL":
				spells.add(new RelocatingSpell(y[1], n1, n2, n3));
				break;

			}

		}
	}

}
