package harrypotter.model.tournament;

public class ThirdTask extends Task { // ?[readMap(String filePath)]
	public void generateMap() {

	}

}
