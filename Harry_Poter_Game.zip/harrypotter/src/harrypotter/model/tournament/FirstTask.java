package harrypotter.model.tournament;

import harrypotter.model.character.Champion;

import java.util.ArrayList;
import java.util.Collections;


public class FirstTask extends Task {

	public FirstTask() {// the constructor should be able to shuffle??
		Collections.shuffle(super.getChampions());
	}

	public void generateMap() {
		super.generateMap();
		for (int i = 0; i < super.getChampions().size(); i++) {
			switch (i) {
			case 0:
				this.map[0][9] = new ChampionCell(champions.get(0));
				break;
			case 1:
				this.map[9][9] = new ChampionCell(champions.get(1));
				break;
			case 2:
				this.map[9][0] = new ChampionCell(champions.get(2));
				break;
			case 3:
				this.map[0][0] = new ChampionCell(champions.get(3));
				break;
			}
			for(int j=0;j<40;j++){
				int obsrand=200+(int)(Math.random()*301);
				while(ran!=)
				
			}
		
		}

	}
}
