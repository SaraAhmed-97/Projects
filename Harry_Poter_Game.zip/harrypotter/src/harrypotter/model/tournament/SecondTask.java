package harrypotter.model.tournament;

import java.util.Collections;

public class SecondTask extends Task{
	
	public SecondTask(){//the constructor should shuffle??
		Collections.shuffle(super.getChampions());

		
	}
	public void generateMap(){
		super.generateMap();
	
		for (int i = 0; i < champions.size(); i++) {
			switch (i) {
			case 0:
				this.map[0][9] = new ChampionCell(champions.get(0));
				break;
			case 1:
				this.map[9][9] = new ChampionCell(champions.get(1));
				break;
			case 2:
				this.map[9][0] = new ChampionCell(champions.get(2));
				break;
			case 3:
				this.map[0][0] = new ChampionCell(champions.get(3));
				break;
			}
		
	}

}}
