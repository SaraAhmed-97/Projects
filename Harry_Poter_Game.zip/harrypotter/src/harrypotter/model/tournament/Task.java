package harrypotter.model.tournament;

import harrypotter.model.character.Champion;
import harrypotter.model.character.Wizard;
import harrypotter.model.magic.Potion;

import java.util.ArrayList;
/*import java.io.BufferedReader; 
 import java.io.FileReader; 
 import java.io.IOException;*/
import java.util.Collections;

import javafx.scene.control.Cell;

public abstract class Task {
	private ArrayList<Champion> champions;
	private Champion currentChamp;
	private Cell[][] map;
	private int allowedMoves;
	private boolean traitActivated;
	private ArrayList<Potion> potions;

	public Task(ArrayList<Champion> champions) {
		// //the three subclasses should generate the map by calling
		// appropiate method
		this.traitActivated=false;
		this.allowedMoves=1;
		this.champions = champions;
		this.map = new Cell[10][10];
		potions.loadPotions("Database-Potions.csv");

	}

	public Task() {

	}

	public void generateMap() {
		int size = champions.size();

		for (int i = size - 1; i < size; i--) {
			if (((Wizard) champions.get(i)).getHp() == 0)
				champions.remove(i);
		}
		
	
			

			for (int j = 0; j < 10;) {
				int x = (int) (Math.random() * potions.size());
				int row = (int) (Math.random() * 10);
				int col = (int) (Math.random() * 10);
				if (map[row][col] == null) {
					map[row][col] = new CollectibleCell(potions.get(x));
					j++;
				}

			}

		}
	}

	public ArrayList<Champion> getChampions() {
		return champions;
	}

	public Champion getCurrentChamp() {
		return currentChamp;
	}

	public void setCurrentChamp(Champion currentChamp) {
		this.currentChamp = currentChamp;
	}

	public Cell[][] getMap() {
		return map;
	}

	public int getAllowedMoves() {
		return allowedMoves;
	}

	public void setAllowedMoves(int allowedMoves) {
		this.allowedMoves = allowedMoves;
	}

	public boolean isTraitActivated() {
		return traitActivated;
	}

	public void setTraitActivated(boolean traitActivated) {
		this.traitActivated = traitActivated;
	}

	public ArrayList<Potion> getPotions() {
		return potions;
	}

}
