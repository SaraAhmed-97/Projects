package harrypotter.model.character;

public class SlytherinWizard extends Wizard {
	private Direction traitDirection;
	public SlytherinWizard(String name) {
		super(name);
		super.setDefaultHp(850);
		super.setDefaultIp(550);
		super.setHp(850);
		super.setIp(550);
		super.setTraitCooldown(0);

	}
	public void useTrait(){
		
	}
	public Direction getTraitDirection() {
		return traitDirection;
	}
	public void setTraitDirection(Direction traitDirection) {
		this.traitDirection = traitDirection;
	}

}
