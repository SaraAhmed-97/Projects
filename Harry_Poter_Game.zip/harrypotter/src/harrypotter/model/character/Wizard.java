package harrypotter.model.character;
import java.awt.Point;
import java.util.ArrayList;
import harrypotter.model.magic.Collectible;
import harrypotter.model.magic.Spell;
public abstract class Wizard implements Champion{
	private String name;
	private int defaultHp;
	private int defaultIp;
	private int hp;
	private int ip;
	private ArrayList<Spell> spells;
	private ArrayList<Collectible> inventory;
	private Point location;
	private int traitCooldown;

	public Wizard(String name) {
		this.name = name;
	}

	public Wizard() {

	}

	public String getName() {
		return name;
	}

	public int getDefaultHp() {
		return defaultHp;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDefaultHp(int defaultHp) {
		this.defaultHp = defaultHp;
	}

	public void setDefaultIp(int defaultIp) {
		this.defaultIp = defaultIp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public void setIp(int ip) {
		this.ip = ip;
	}

	public void setLocation(Point location) {
		this.location = location;
	}

	public void setTraitCooldown(int traitCooldown) {
		this.traitCooldown = traitCooldown;
	}

	public int getDefaultIp() {
		return defaultIp;
	}

	public int getHp() {
		return hp;
	}

	public int getIp() {
		return ip;
	}

	public Point getLocation() {
		return location;
	}

	public int getTraitCooldown() {
		return traitCooldown;
	}

}
