package harrypotter.model.character;

public interface Champion {
	public void useTrait();

}
