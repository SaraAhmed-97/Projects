package harrypotter.model.character;

public class RavenclawWizard extends Wizard  {
	public RavenclawWizard(String name) {
		super(name);
		super.setDefaultHp(750);
		super.setDefaultIp(700);
		super.setHp(750);
		super.setIp(700);
		super.setTraitCooldown(0);

	}
	public void useTrait(){
		
	}

}
