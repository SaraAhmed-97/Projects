package harrypotter.model.character;

public class HufflepuffWizard extends Wizard  {
	public HufflepuffWizard(String name) {
		super(name);
		super.setDefaultHp(1000);
		super.setDefaultIp(450);
		super.setHp(1000);
		super.setIp(450);
		super.setTraitCooldown(0);

	}
	public void useTrait(){
		
	}

}
